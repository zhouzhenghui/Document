IOMux-v2.0.11

The key new features in this version are:

- ball map visualized showing what's assigned and any conflicts
- comments may be added for each signal for documentation
- summary of assignments with comments can be printed

To use the IOMUX tool:
1) Launch the tool
2) Select the device to be used or File>Open a saved design
3) Check desired signals/peripheral groups in the left pane
4) Resolve conflicts by changing ball assignments for signals
5) Add comments in Signals tab by right clicking on a signal line
6) File>Save the design, if desired
7) Print the signal assignments to paper or a PDF, or copy the signal information in the Signals tab to paste into an application design document or schematic.

* Requires Microsoft .NET Framework 3.5
http://www.microsoft.com/downloads/en/details.aspx?FamilyID=333325FD-AE52-4E35-B531-508D977D32A6&displaylang=en
